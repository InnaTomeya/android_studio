package com.example.chatghost;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebSocketManager webSocketManager;
    private TextView chatView;
    private EditText inputField;
    private EditText nameField; // ← добавлено
    private Button sendButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chatView = findViewById(R.id.chatView);
        inputField = findViewById(R.id.inputField);
        nameField = findViewById(R.id.nameField); // ← новое поле
        sendButton = findViewById(R.id.sendButton);

        webSocketManager = new WebSocketManager(new WebSocketManager.WebSocketCallback() {
            @Override
            public void onOpen() {
                runOnUiThread(() -> chatView.append("Connected to chat\n"));
            }

            @Override
            public void onMessage(String message) {
                runOnUiThread(() -> chatView.append(message + "\n"));
            }


            @Override
            public void onClose() {
                runOnUiThread(() -> chatView.append("Disconnected\n"));
            }

            @Override
            public void onError(Throwable t) {
                runOnUiThread(() -> chatView.append("Error: " + t.getMessage() + "\n"));
            }
        });

        sendButton.setOnClickListener(view -> {
            String msg = inputField.getText().toString();
            String name = nameField.getText().toString();
            if (!msg.isEmpty() && !name.isEmpty()) {
                String fullMessage = name + ": " + msg;
                webSocketManager.sendMessage(fullMessage);

                runOnUiThread(() -> chatView.append(fullMessage + "\n")); // ⬅ добавляем своё сообщение

                inputField.setText("");
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        webSocketManager.close();
    }
}
