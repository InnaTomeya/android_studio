package com.example.chatghost;

import android.util.Log;
import org.json.JSONObject;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class WebSocketManager {
    private WebSocket webSocket;
    private final String SERVER_URL = "ws://192.168.1.78:8081";
    private WebSocketCallback callback;

    public WebSocketManager(WebSocketCallback callback) {
        this.callback = callback;
        connect();
    }

    private void connect() {
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder().url(SERVER_URL).build();
        webSocket = client.newWebSocket(request, new WebSocketListener() {
            @Override
            public void onOpen(WebSocket ws, okhttp3.Response response) {
                callback.onOpen();
            }

            @Override
            public void onMessage(WebSocket ws, String text) {
                try {
                    if (text.contains("publicKey")) {
                        JSONObject obj = new JSONObject(text);
                        if ("publicKey".equals(obj.getString("type"))) {
                            String pem = obj.getString("key");
                            EncryptionUtils.setPublicKey(pem);
                            return;
                        }
                    }
                    String decrypted = EncryptionUtils.decrypt(text);
                    callback.onMessage(decrypted);
                } catch (Exception e) {
                    callback.onMessage(text);
                }
            }

            @Override
            public void onFailure(WebSocket ws, Throwable t, okhttp3.Response response) {
                callback.onError(t);
            }

            @Override
            public void onClosing(WebSocket ws, int code, String reason) {
                callback.onClose();
            }
        });
    }

    public void sendMessage(String message) {
        if (webSocket != null) {
            String encrypted = EncryptionUtils.encrypt(message);
            webSocket.send(encrypted);
        }
    }

    public void close() {
        if (webSocket != null) {
            webSocket.close(1000, "Closing");
        }
    }

    public interface WebSocketCallback {
        void onOpen();
        void onMessage(String message);
        void onClose();
        void onError(Throwable t);
    }
}
