package com.example.chatghost;

import android.util.Base64;
import android.util.Log;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.util.io.pem.PemReader;
import java.io.StringReader;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import javax.crypto.Cipher;

public class EncryptionUtils {
    private static PublicKey publicKey = null;

    static {
        Security.addProvider(new BouncyCastleProvider());
    }

    public static void setPublicKey(String pemKey) {
        try {
            PemReader pemReader = new PemReader(new StringReader(pemKey));
            byte[] content = pemReader.readPemObject().getContent();
            X509EncodedKeySpec spec = new X509EncodedKeySpec(content);
            publicKey = KeyFactory.getInstance("RSA").generatePublic(spec);
            Log.d("Encryption", "Публичный ключ загружен");
        } catch (Exception e) {
            Log.e("Encryption", "Ошибка загрузки публичного ключа", e);
        }
    }

    public static String encrypt(String message) {
        try {
            if (publicKey == null) return message;
            Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] encryptedBytes = cipher.doFinal(message.getBytes("UTF-8"));
            return Base64.encodeToString(encryptedBytes, Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e("Encryption", "Ошибка шифрования", e);
            return message;
        }
    }

    public static String decrypt(String text) {
        return text; // не используется, сервер уже расшифровал
    }
}
